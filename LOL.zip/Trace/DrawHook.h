#pragma once
#include "Trace.h"


namespace DrawHook
{
	/// <summary>
	/// һ�еĿ�ʼ
	/// </summary>
	void Start();
}

